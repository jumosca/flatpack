FLATPACK-REGULAR
A display typeface by Julie Moscatelli.

Inspired by a long wander through an IKEA store, noticing how many of
their furniture pieces looked like letters — flatpack shelves, sectioned
wardrobes, angled chair legs. An alphabet hiding in plain sight.

This typeface is an independent design and is not affiliated with,
endorsed by, or licensed by Inter IKEA Systems B.V.

-----------------------------------------------------------
Format:   TrueType (.ttf)
Weight:   Regular (400)
Year:     2026
Licence:  SIL Open Font License 1.1 (see OFL.txt)
-----------------------------------------------------------

Designer: Julie Moscatelli
Email:    julie.moscatelli@gmail.com
